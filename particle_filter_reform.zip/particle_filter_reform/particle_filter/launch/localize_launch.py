from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration
from launch.actions import DeclareLaunchArgument
from ament_index_python.packages import get_package_share_directory
import os
import yaml

def generate_launch_description():
    # Config and args
    package_path = get_package_share_directory('particle_filter')
    
    # Declare all potential parameters as launch arguments
    launch_args = [
        DeclareLaunchArgument(
            'localize_config',
            default_value=os.path.join(package_path, 'config', 'localize.yaml'),
            description='Path to localization config file'
        ),
        DeclareLaunchArgument(
            'lidar_aspect_ratio',
            default_value='3.0',
            description='Width/height ratio for the boxed pattern'
        ),
        DeclareLaunchArgument(
            'des_lidar_beams',
            default_value='21',
            description='Desired number of output beams (must be odd)'
        ),
        DeclareLaunchArgument(
            'angle_step',
            default_value='1',
            description='Downsampling step for lidar angles'
        )
    ]

    # Load existing config file
    localize_config_dict = yaml.safe_load(open(LaunchConfiguration('localize_config').perform(), 'r'))
    map_name = localize_config_dict['map_server']['ros__parameters']['map']

    # Node definitions
    pf_node = Node(
        package='particle_filter',
        executable='particle_filter',
        name='particle_filter',
        parameters=[
            LaunchConfiguration('localize_config'),
            {
                'lidar_aspect_ratio': LaunchConfiguration('lidar_aspect_ratio'),
                'des_lidar_beams': LaunchConfiguration('des_lidar_beams'),
                'angle_step': LaunchConfiguration('angle_step')
            }
        ]
    )

    map_server_node = Node(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        parameters=[{
            'yaml_filename': os.path.join(package_path, 'maps', f'{map_name}.yaml'),
            'topic': 'map',
            'frame_id': 'map',
            'use_sim_time': True
        }]
    )

    nav_lifecycle_node = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_localization',
        parameters=[{
            'use_sim_time': True,
            'autostart': True,
            'node_names': ['map_server']
        }]
    )

    return LaunchDescription([
        *launch_args,
        nav_lifecycle_node,
        map_server_node,
        pf_node
    ])